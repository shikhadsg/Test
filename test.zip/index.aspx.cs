﻿using Bussinesslogic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class index : System.Web.UI.Page
{
    #region DeclareVariable
    LoginModuleBL obj = new LoginModuleBL();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Fetch the Cookie using its Key.
            HttpCookie ReqCookies = Request.Cookies["LoginDetails"];
            if (ReqCookies != null)
            {
                //Removes all keys and values from the session-state collection.
                HttpContext.Current.Session.Clear();
                //Cancels the current session.
                HttpContext.Current.Session.Abandon();
                Session.Clear();
                Session.Abandon();

                //Set the Expiry date to past date.
                ReqCookies.Expires = DateTime.Now.AddDays(-1);

                //Update the Cookie in Browser.
                Response.Cookies.Add(ReqCookies);
            }
        }
    }
    #region UserLoginCode
    protected void btnUserLogin_Click(object sender, EventArgs e)
    {
        try
        {
            if (Page.IsValid)
            {
                string UserName = txtUserId.Text.Trim();
                string Password = txtUserPassword.Text.Trim();
                DataSet ds = obj.UserLoginDetailsBL(UserName, Password);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (ds.Tables[0].Rows[0]["UserStatus"].ToString().Equals("A"))
                    {
                        HttpCookie cookie = new HttpCookie("LoginDetails");

                        cookie["UserId"] = ds.Tables[0].Rows[0]["UserId"].ToString();
                        cookie["UserName"] = ds.Tables[0].Rows[0]["UserName"].ToString();
                        cookie["UserStatus"] = ds.Tables[0].Rows[0]["UserStatus"].ToString();
                        cookie["RoleId"] = ds.Tables[0].Rows[0]["RoleId"].ToString();
                        Response.Cookies.Add(cookie);
                        Response.Cookies["LoginDetails"].Expires = DateTime.Now.AddDays(1);
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('success', 'User ID and password have been authenticated successfully.', 'Success', 'Admin/DashBoard.aspx','1000');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Authentication Failed. Your account is not Active.Please request Admin Team to Activate your account.', 'Error');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "showErrorToast", "showToast('error', 'Authentication Failed. Your User Id or password is incorrect.Please verify your User Id or Password.', 'Error');", true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}