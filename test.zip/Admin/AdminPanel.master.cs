﻿using Bussinesslogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AdminPanel : System.Web.UI.MasterPage
{
    #region VariableDeclare
    LoginModuleBL obj = new LoginModuleBL();
    protected string UserName = string.Empty;
    #endregion
    protected void Page_Init(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            HttpCookie ReqCookies = Request.Cookies["LoginDetails"];
            if (ReqCookies != null)
            {
                if (Session["UserId"] == null)
                {
                    Session["UserId"] = ReqCookies["UserId"].ToString();
                    Session["UserName"] = ReqCookies["UserName"].ToString();
                    Session["UserStatus"] = ReqCookies["UserStatus"].ToString();
                    Session["RoleId"] = ReqCookies["RoleId"].ToString();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'Your session has expired. Please log in again to continue.', 'Session Expired', 'Login','2000');", true);
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                //lblTodayDate.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy");
                if (!IsPostBack)
                {
                    UserName = "Welcome:- " + Session["UserName"].ToString();
                }
            }
        }
    }
    #region LogoutUser
    protected void lnlLogout_Click(object sender, EventArgs e)
    {
        try
        {
            ClearSession();
            RedirectToLoginPage();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region ClearSession
    private void ClearSession()
    {
        try
        {
            // Clear specific session variables if needed
            Session.Remove("UserId");
            Session.Remove("UserName");
            Session.Remove("UserStatus");
            Session.Remove("RoleId");

            // Abandon the current session
            Session.Clear();
            Session.Abandon();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
    #region RedirectToLoginPage
    private void RedirectToLoginPage()
    {
        try
        {
            // Redirect to the login page or any other desired destination
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showToastAndRedirect", "showToastAndRedirect('error', 'You have successfully logged out. Thank you for using the portal!', 'Logout Successful', '../index.aspx','1000');", true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}
