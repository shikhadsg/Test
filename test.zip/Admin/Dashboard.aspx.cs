﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ApiSalesData_Dashboard : System.Web.UI.Page
{
    #region
    StiExam obj = new StiExam();
    protected string TotalCourse = string.Empty;
    protected string TotalCandidate = string.Empty;
    protected string TotalInActiveOrder = string.Empty;
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                GetCourseDetails();
            }
        }
    }
    #region GetCourseDetails
    private void GetCourseDetails()
    {
        try
        {
            DataSet ds = obj.GetCourseDetails(Session["UserId"].ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}