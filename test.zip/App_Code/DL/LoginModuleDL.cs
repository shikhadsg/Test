﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DataAccess
{
    public class LoginModuleDL : MyDBConnection
    {
        #region Variable Declaration
        SqlConnection con;
        ELPConnection sCon;
        SqlCommand cmd;
        #endregion

        #region UserLoginDetailsDL
        public DataSet UserLoginDetailsDL(string UserName, string Password)
        {
            DataSet ds = new DataSet();
            try
            {
                sCon = new ELPConnection();
                con = new SqlConnection();
                cmd = new SqlCommand();
                using (con = sCon.getConnection())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = Constants.Usp_UserLoginDetails;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserName", DbType = DbType.String, Value = UserName });
                        cmd.Parameters.Add(new SqlParameter { ParameterName = "@Password", DbType = DbType.String, Value = Password });
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                cmd.Dispose();
                sCon = null;
            }
            return ds;
        }
        #endregion
        #region AddUpdateUserMapDetails
        public int AddUpdateUserMapDetails(string EmpCode, string ReportingToCode, string VpHeadCode)
        {
            int success = 0;
            try
            {
                sCon = new ELPConnection();
                con = new SqlConnection();
                cmd = new SqlCommand();
                using (con = sCon.getConnection())
                {
                    using (cmd = con.CreateCommand())
                    {
                        cmd.CommandText = "Usp_AddUpdateUserMapDetails";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter { ParameterName = "@EmpCode", DbType = DbType.String, Value = EmpCode });
                        cmd.Parameters.Add(new SqlParameter { ParameterName = "@ReportingToCode", DbType = DbType.String, Value = ReportingToCode });
                        cmd.Parameters.Add(new SqlParameter { ParameterName = "@VpHeadCode", DbType = DbType.String, Value = VpHeadCode });
                        success = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                cmd.Dispose();
                sCon = null;
            }
            return success;
        }
        #endregion
        //DataSet ds = new DataSet();
        //string result = string.Empty;
        //#region
        //public DataSet UserLoginDetailsDL(string UserName,string Password)
        //{
        //    dbManager.CreateParameters(1);
        //    dbManager.AddParameters(0, "@UserCode", "");
        //    try
        //    {
        //        dbManager.Open();
        //        ds = dbManager.ExecuteDataSet(CommandType.StoredProcedure, Constants.Select_LookupUser);
        //        return ds;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw new ApplicationException(ex.Message.ToString());
        //    }
        //    finally
        //    {
        //        dbManager.Close();
        //        dbManager.Dispose();
        //    }
        //}
        //#endregion
    }
}
