﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Net.Mail;
using System.Net;

/// <summary>
/// Summary description for MailUtility
/// </summary>
public class MailUtility
{
   ProjectConfi pconfig = new ProjectConfi();
    #region SendMailForPopTracker
    public bool SendMailForPopTracker(string SenderUserEmail, string SenderUserName, string ReceiverEmail, string ReceiverName, string Subject, string Body,string Remarks ,string Url = "https://intranet.dsgroup.com/intranet/home.aspx")
    {
        string MailReceiver = "manish.kumar1@dsgroup.com";
        ProjectConfi pconfig = new ProjectConfi();
        string urlDomain = System.Configuration.ConfigurationManager.AppSettings["connectionUrl"].ToString();
        MailAddress _fromMailAddress = new MailAddress(SenderUserEmail, SenderUserName);
        //MailAddress _bccMailAddress = new MailAddress(SentByEmail, SentByUserName);
        SmtpClient smtpClient = new SmtpClient();
        smtpClient.Host = pconfig.MailServer;
        smtpClient.Port = pconfig.MailPort;
        smtpClient.EnableSsl = pconfig.MailIsSSL;
        smtpClient.UseDefaultCredentials = true;
        smtpClient.Credentials = new NetworkCredential(pconfig.MailSenderUsername, pconfig.MailSenderPassword);
        MailMessage _mailMessage = new MailMessage();
        _mailMessage.IsBodyHtml = true;
        _mailMessage.From = _fromMailAddress;
        //_mailMessage.Bcc.Add(_fromMailAddress);
        _mailMessage.CC.Add("prakash.singh@dsgroup.com");
       // string[] mailids = ReceiverEmail.Split(',');
        string[] mailids = MailReceiver.Split(',');
        foreach (string id in mailids)
        {
            _mailMessage.To.Add(new MailAddress(id));
        }
        _mailMessage.Subject = HttpUtility.HtmlEncode(Subject);
        string HtmlBody = "<div style='margin:0;padding:0 15px'>";
        HtmlBody = HtmlBody + "<table width='100%' cellspacing='0' cellpadding='0' style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<tbody><tr style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<td style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>Dear " + ReceiverName + ",</b></p>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>" + Body + "</b></p>";
        if (!string.IsNullOrEmpty(Remarks) && !string.IsNullOrEmpty(Remarks))
        {
            HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>Request Status:- " + Remarks + "</b></p>";
        }
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>Click here to take action <a href='" + Url + "' target='_blank'>Click Here</a></b></p>";
        HtmlBody = HtmlBody + "</td>";
        HtmlBody = HtmlBody + "</tr>";
        HtmlBody = HtmlBody + "</tbody></table>";
        HtmlBody = HtmlBody + "<table width='100%' cellspacing='0' cellpadding='0' style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<tbody><tr style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<td style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>Thanks & Regards,</b></p>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>" + SenderUserName + "</b></p>";
        HtmlBody = HtmlBody + "</td>";
        HtmlBody = HtmlBody + "</tr>";
        HtmlBody = HtmlBody + "</tbody></table>";
        HtmlBody = HtmlBody + "</div>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "</div>";
        _mailMessage.Body = (HtmlBody);
        _mailMessage.IsBodyHtml = true;
       // smtpClient.Send(_mailMessage);
        return true;
    }
    #endregion
    #region SentMailToNoidaForDispatch
    public bool SentMailToNoidaForDispatch(string SenderUserEmail, string SenderUserName, string ToMail, string ReceiverName, string CcMail ,string Subject, string Body,string Attachment, string Url)
    {
        ProjectConfi pconfig = new ProjectConfi();
        string urlDomain = System.Configuration.ConfigurationManager.AppSettings["connectionUrl"].ToString();
        MailAddress _fromMailAddress = new MailAddress(SenderUserEmail, SenderUserName);
        //MailAddress _bccMailAddress = new MailAddress(SentByEmail, SentByUserName);
        SmtpClient smtpClient = new SmtpClient();
        smtpClient.Host = pconfig.MailServer;
        smtpClient.Port = pconfig.MailPort;
        smtpClient.EnableSsl = pconfig.MailIsSSL;
        smtpClient.UseDefaultCredentials = true;
        smtpClient.Credentials = new NetworkCredential(pconfig.MailSenderUsername, pconfig.MailSenderPassword);
        MailMessage _mailMessage = new MailMessage();
        _mailMessage.IsBodyHtml = true;
        _mailMessage.From = _fromMailAddress;
        //_mailMessage.Bcc.Add(_fromMailAddress);
        string[] mailids = ToMail.Split(';');
        foreach (string id in mailids)
        {
            _mailMessage.To.Add(new MailAddress(id));
        }
        string[] CcMailId = CcMail.Split(';');
        foreach (string CcId in CcMailId)
        {
            _mailMessage.To.Add(new MailAddress(CcId));
        }

        _mailMessage.Subject = HttpUtility.HtmlEncode(Subject);
        string HtmlBody = "<div style='margin:0;padding:0 15px'>";
        HtmlBody = HtmlBody + "<table width='100%' cellspacing='0' cellpadding='0' style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<tbody><tr style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<td style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>Dear " + ReceiverName + ",</b></p>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>" + Body + "</b></p>";
        //if (!string.IsNullOrEmpty(Remarks) && !string.IsNullOrEmpty(Remarks))
        //{
        //    HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>Request Status:- " + Remarks + "</b></p>";
        //}
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>Click here to take action <a href='" + Url + "' target='_blank'>Click Here</a></b></p>";
        HtmlBody = HtmlBody + "</td>";
        HtmlBody = HtmlBody + "</tr>";
        HtmlBody = HtmlBody + "</tbody></table>";
        HtmlBody = HtmlBody + "<table width='100%' cellspacing='0' cellpadding='0' style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<tbody><tr style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<td style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>Thanks & Regards,</b></p>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>" + SenderUserName + "</b></p>";
        HtmlBody = HtmlBody + "</td>";
        HtmlBody = HtmlBody + "</tr>";
        HtmlBody = HtmlBody + "</tbody></table>";
        HtmlBody = HtmlBody + "</div>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "</div>";
        _mailMessage.Body = (HtmlBody);
        _mailMessage.IsBodyHtml = true;
        if (!string.IsNullOrEmpty(Attachment) && System.IO.File.Exists(Attachment))
        {
            Attachment mailAttachment = new Attachment(Attachment);
            _mailMessage.Attachments.Add(mailAttachment);
        }
        // smtpClient.Send(_mailMessage);
        return true;
    }
    #endregion
    #region SendUpcomingLitigationMail
    public bool SendUpcomingLitigationMail(string SenderUserEmail, string SenderUserName, string ReceiverEmail, string ReceiverName, string Subject, string Body, string Attachment)
    {
        // string MailReceiver = "prakash.singh@dsgroup.com";
        ProjectConfi pconfig = new ProjectConfi();
        string urlDomain = System.Configuration.ConfigurationManager.AppSettings["connectionUrl"].ToString();
        MailAddress _fromMailAddress = new MailAddress(SenderUserEmail, SenderUserName);
        //MailAddress _bccMailAddress = new MailAddress(SentByEmail, SentByUserName);
        SmtpClient smtpClient = new SmtpClient();
        smtpClient.Host = pconfig.MailServer;
        smtpClient.Port = pconfig.MailPort;
        smtpClient.EnableSsl = pconfig.MailIsSSL;
        smtpClient.UseDefaultCredentials = true;
        smtpClient.Credentials = new NetworkCredential(pconfig.MailSenderUsername, pconfig.MailSenderPassword);
        MailMessage _mailMessage = new MailMessage();
        _mailMessage.IsBodyHtml = true;
        _mailMessage.From = _fromMailAddress;
        //_mailMessage.Bcc.Add(_fromMailAddress);
        //_mailMessage.CC.Add("efc-helpdesk@gov.in");
        string[] mailids = ReceiverEmail.Split(',');
        //string[] mailids = MailReceiver.Split(',');
        foreach (string id in mailids)
        {
            _mailMessage.To.Add(new MailAddress(id));
        }
        _mailMessage.Subject = HttpUtility.HtmlEncode(Subject);
        string HtmlBody = "<div style='margin:0;padding:0 15px'>";
        HtmlBody = HtmlBody + "<table width='100%' cellspacing='0' cellpadding='0' style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<tbody><tr style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<td style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>Dear " + ReceiverName + ",</b></p>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'>" + Body + "</b></p>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "</td>";
        HtmlBody = HtmlBody + "</tr>";
        HtmlBody = HtmlBody + "</tbody></table>";
        HtmlBody = HtmlBody + "<table width='100%' cellspacing='0' cellpadding='0' style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<tbody><tr style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<td style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>Thanks & Regards,</b></p>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6'><b>" + SenderUserName + "</b></p>";
        HtmlBody = HtmlBody + "</td>";
        HtmlBody = HtmlBody + "</tr>";
        HtmlBody = HtmlBody + "</tbody></table>";
        HtmlBody = HtmlBody + "</div>";
        HtmlBody = HtmlBody + "<br style='margin:0;padding:0'>";
        HtmlBody = HtmlBody + "<p style='margin:0;padding:0;margin-bottom:5px;color:#585858;font-weight:400;font-size:13px;line-height:1.6;color:red;'><b>Note: This is a system generated E-mail, please do not reply to this E-mail and ignore. </b></p>";
        HtmlBody = HtmlBody + "</div>";
        _mailMessage.Body = (HtmlBody);
        _mailMessage.IsBodyHtml = true;
        if (!string.IsNullOrEmpty(Attachment) && System.IO.File.Exists(Attachment))
        {
            Attachment mailAttachment = new Attachment(Attachment);
            _mailMessage.Attachments.Add(mailAttachment);
        }
        smtpClient.Send(_mailMessage);
        return true;
    }
    #endregion
}