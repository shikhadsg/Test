﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Configuration;


    public partial class ProjectConfi
    {
    #region constructor
    public ProjectConfi()
    {
    }
	#endregion
	#region mailserver
	public string  MailServer
    {
        get {
            return WebConfigurationManager.AppSettings["SmtpHost"].ToString();
        }
        set { }
    }
    public Int16 MailPort
    {
        get {
            return Int16.Parse(WebConfigurationManager.AppSettings["Port"].ToString());
        }
        set {  }
    }
    public Boolean MailIsSSL
        {
        get {
            return Boolean.Parse(WebConfigurationManager.AppSettings["MailIsSSL"].ToString());
        }
        set { }
        }
    public string MailSenderEmail
    {
        get {
            return WebConfigurationManager.AppSettings["FromAddress"].ToString();
        }
    }
    public string MailSenderUsername
        {
        get {
            return WebConfigurationManager.AppSettings["UserName"].ToString();
        }
        }
    #endregion
    #region MailSenderPassword
    public string MailSenderPassword
    {
        get
        {
            return WebConfigurationManager.AppSettings["Password"].ToString();

        }
    }
    #endregion
    #region MailSenderDisplayName
    public string MailSenderDisplayName
    {
        get {
            return WebConfigurationManager.AppSettings["MailSenderDisplayName"].ToString();
        }
    }
    #endregion
}
