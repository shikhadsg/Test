﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using DataAccess;
using System.Data;

/// <summary>
/// Summary description for StiExam
/// </summary>
public class StiExam
{
    #region VariableDeclaration
    SqlConnection con;
    ConnectionCode sCon;
    SqlCommand cmd;
    #endregion
    #region GetCourseDetails
    public DataSet GetCourseDetails(string UserId)
    {
        DataSet ds = new DataSet();
        try
        {
            sCon = new ConnectionCode();
            con = new SqlConnection();
            cmd = new SqlCommand();
            using (con = sCon.getConnection())
            {
                using (cmd = con.CreateCommand())
                {
                    cmd.CommandText = "Usp_GetCourseDetails";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter { ParameterName = "@UserId", DbType = DbType.String, Value = UserId });
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            cmd.Dispose();
            sCon = null;
        }
        return ds;
    }
    #endregion
}